import pandas as pd
from json_parser.message_reader import start
from google_sheet_handler import sheet_updater, sheet_reader
import os

json_file = "var.json"
sheet_ID = 'SHEET_ID'

if sheet_ID == 'SHEET_ID':
    print('Please set sheet ID before starting this program')
if not os.path.exists('credentials.json'):
    print("Please get credentials.json file from your google account & make sure it's in same folder")
if not os.path.exists(json_file):
    print(" File not found", json_file)
# reading input file & sheet
xls = sheet_reader(sheet_ID)
df = pd.DataFrame(xls)
final_written = None


def to_every_message(row):
    """
    row for excel sheet
    :param row:
    """
    global final_written
    cell_value = row[0]

    # getting response from core function
    path_list, response_list = start()

    write_list = [(cell_value, "", "")]
    for new_row in zip(path_list, response_list):
        write_list.append(("send", "text", new_row[0]))
        write_list.append(("expectPayload", "equalTo", new_row[1]))
    if final_written is None:
        final_written = write_list
    else:
        final_written += write_list


# after reading each yellow lable applying function
df.apply(to_every_message, raw=True, axis=1)

# writing output in google sheet
sheet_updater(data_frame=final_written, sheet_ID=sheet_ID)
