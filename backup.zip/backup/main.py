import pandas as pd
import json

xls = pd.ExcelFile('Requirements.xlsx')
df = pd.read_excel(xls, 'Yellow Sheet')
for line in df:
    print(line)





exit()




